package com.insurance.InsuranceApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
