import { useContext, useEffect, useState } from 'react';
import AuthContext from '../context/AuthContext';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const DashboardPage = () => {
  const { currentUser, logout } = useContext(AuthContext);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDashboardContent = async () => {
      if (!currentUser || !currentUser.token) {
        setError("Not authenticated. Please log in.");
        return;
      }
      try {
        const response = await axios.get('http://localhost:8093/api/dashboard', {
          headers: {
            Authorization: `Bearer ${currentUser.token}`,
          },
        });
        setMessage(response.data);
      } catch (err) {
        console.error("Error fetching dashboard content:", err);
        setError("Failed to fetch dashboard content. You might not have admin access or your session expired.");
        if (err.response && err.response.status === 403) {
            navigate('/home');
        } else if (err.response && err.response.status === 401) {
            logout();
        }
      }
    };

    fetchDashboardContent();
  }, [currentUser, logout, navigate]);

  return (
    <div className="container-fluid bg-primary bg-gradient text-white d-flex flex-column justify-content-center align-items-center min-vh-100 p-4">
      <div className="card shadow-lg p-5 bg-white text-dark text-center" style={{ maxWidth: '700px', width: '100%' }}>
        <h1 className="card-title display-4 fw-bold mb-3">Admin Dashboard</h1>
        {currentUser && (
          <p className="card-text fs-4 mb-4">Hello, <span className="text-secondary">{currentUser.username}</span>! You have <span className="text-secondary">{currentUser.role}</span> access.</p>
        )}
        <p className="card-text fs-5 mb-5">
          {message || "Loading content..."}
        </p>
        {error && (
          <div className="alert alert-danger text-center mb-4" role="alert">
            {error}
          </div>
        )}
        <button
          onClick={logout}
          className="btn btn-danger btn-lg rounded-pill shadow-sm px-5 py-3 mt-3"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default DashboardPage;
