import { useContext, useEffect, useState } from 'react';
import AuthContext from '../context/AuthContext';
import axios from 'axios';

const HomePage = () => {
  const { currentUser, logout } = useContext(AuthContext);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchHomeContent = async () => {
      if (!currentUser || !currentUser.token) {
        setError("Not authenticated. Please log in.");
        return;
      }
      try {
        const response = await axios.get('http://localhost:8093/api/home', {
          headers: {
            Authorization: `Bearer ${currentUser.token}`,
          },
        });
        setMessage(response.data);
      } catch (err) {
        console.error("Error fetching home content:", err);
        setError("Failed to fetch home content. You might not have access or your session expired.");
        if (err.response && err.response.status === 401) {
            logout();
        }
      }
    };

    fetchHomeContent();
  }, [currentUser, logout]);

  return (
    <div className="container-fluid bg-info bg-gradient text-white d-flex flex-column justify-content-center align-items-center min-vh-100 p-4">
      <div className="card shadow-lg p-5 bg-white text-dark text-center" style={{ maxWidth: '700px', width: '100%' }}>
        <h1 className="card-title display-4 fw-bold mb-3">Welcome to Your Insurance Portal!</h1>
        {currentUser && (
          <p className="card-text fs-4 mb-4">Hello, <span className="text-primary">{currentUser.username}</span>!</p>
        )}
        <p className="card-text fs-5 mb-5">
          {message || "Loading content..."}
        </p>
        {error && (
          <div className="alert alert-danger text-center mb-4" role="alert">
            {error}
          </div>
        )}
        <button
          onClick={logout}
          className="btn btn-danger btn-lg rounded-pill shadow-sm px-5 py-3 mt-3"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default HomePage;