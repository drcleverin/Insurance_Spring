import { useState } from 'react'; // No need for 'React' import explicitly
import authService from '../api/auth';
import { Link } from 'react-router-dom';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleRequestReset = async (e) => {
    e.preventDefault();
    setMessage('');
    setIsSuccess(false);
    try {
      const response = await authService.requestPasswordReset(email);
      setMessage(response.data.message);
      setIsSuccess(true);
    } catch (error) {
      const resMessage =
        (error.response &&
          error.response.data &&
          error.response.data.message) ||
        error.message ||
        error.toString();
      setMessage(resMessage);
      setIsSuccess(false);
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100 bg-light">
      <div className="card shadow-lg p-4" style={{ maxWidth: '400px', width: '100%' }}>
        <div className="card-body">
          <h2 className="card-title text-center mb-4 text-primary">Forgot Password</h2>
          <p className="text-muted text-center mb-4">Enter your email address and we'll send you a password reset link.</p>
          <form onSubmit={handleRequestReset}>
            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                Email
              </label>
              <input
                type="email"
                id="email"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="d-grid gap-2 mb-3">
              <button
                type="submit"
                className="btn btn-primary btn-lg"
              >
                Request Reset Link
              </button>
            </div>
            {message && (
              <div className={`alert ${isSuccess ? 'alert-success' : 'alert-danger'} text-center mt-3`} role="alert">
                {message}
              </div>
            )}
            <div className="text-center mt-3">
              <Link to="/login" className="text-muted">
                Back to Login
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;