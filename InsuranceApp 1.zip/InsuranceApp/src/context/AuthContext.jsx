// src/context/AuthContext.jsx
import { createContext, useState, useEffect, useCallback, useRef } from 'react';
import authService from '../api/auth';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(authService.getCurrentUser());
  const navigate = useNavigate();
  const timeoutRef = useRef(null);

  const resetInactivityTimer = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    if (currentUser) {
      timeoutRef.current = setTimeout(() => {
        console.log('Session expired due to inactivity');
        logout();
        navigate('/login');
      }, 15 * 60 * 1000); // 15 minutes
    }
  }, [currentUser, navigate]);

  const login = async (username, password) => {
      const data = await authService.login(username, password);
      setCurrentUser(data);
      resetInactivityTimer();
      return data;
    
  };

  const logout = useCallback(() => {
    authService.logout();
    setCurrentUser(null);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    navigate('/login');
  }, [navigate]);

  useEffect(() => {
    resetInactivityTimer();

    const activityEvents = ['mousemove', 'keydown', 'click'];
    const handleActivity = () => resetInactivityTimer();

    activityEvents.forEach(event => {
      window.addEventListener(event, handleActivity);
    });

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      activityEvents.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [resetInactivityTimer]);

  return (
    <AuthContext.Provider value={{ currentUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;