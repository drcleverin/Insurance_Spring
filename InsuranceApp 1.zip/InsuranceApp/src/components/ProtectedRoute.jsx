import { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import AuthContext from '../context/AuthContext';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { currentUser } = useContext(AuthContext);

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(currentUser.role.toLowerCase())) {
    console.log("Access Denied: User role '" + currentUser.role + "' not in allowed roles: " + allowedRoles.join(', '));
    return <Navigate to="/home" replace />;
  }

  return children;
};

export default ProtectedRoute;